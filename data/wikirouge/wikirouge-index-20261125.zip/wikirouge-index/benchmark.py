#!/usr/bin/env python3
"""Replay bibliographic lookup on the 14 existing inventory cases, offline.
Inputs from public GitHub Actions run 45670611930, job 139404563001.
Baseline English titles are only used for comparison, not retrieval.
"""
import json
import sqlite3
from pathlib import Path
from time import perf_counter
from lookup import lookup

# case id, article, work, source URL, previous automatic English work
CASES=[
('7d2c5ac9c340338c4c5a',"Les syndicats à l'époque de la décadence impérialiste",'', 'https://www.marxists.org/francais/trotsky/oeuvres/1940/08/19400800.html','Trade Unions in the Epoch of Imperialist Decay'),
('89ff6c0bf7d01b774d2f','Beaucoup de tapage autour de Cronstadt','','https://www.marxists.org/francais/trotsky/oeuvres/1938/01/lt19380115.htm','Hue and Cry Over Kronstadt'),
('a8d97a06d36267942f81','','Histoire de la révolution russe','https://www.marxists.org/francais/trotsky/livres/hrrusse/hrr42.htm','The History of the Russian Revolution'),
('92f8d1c97cf624989c47','Trente ans après la Révolution russe','','https://www.marxists.org/francais/serge/works/1947/07/serge_19470700.htm',None),
('37895a16e5519563049b','Résolution relative au militarisme et aux conflits internationaux','','https://www.marxists.org/francais/inter_soc/stuttgart_1907/19070800_inter_soc_stuttgart_e.htm',None),
('3e406a8abe6bf4a2ade0','Réponse à des questions de morale et d’histoire','','https://www.marxists.org/francais/trotsky/oeuvres/1937/07/lt19370706.htm',None),
('04d87b872404cd263bdc','','Anti-Dühring','https://www.marxists.org/francais/engels/works/1878/06/fe18780611.htm','Anti-Dühring'),
('cbcb50ccd2dc846ade99','',"L'État et la révolution",'https://www.marxists.org/francais/lenin/works/1917/08/er00t.htm','The State and Revolution'),
('ce93483e966335e9b33d','','Terrorisme et communisme','https://www.marxists.org/francais/trotsky/livres/t_c/t_c.htm','Terrorism and Communism'),
('f287bb5aaedadaa0c506','','La crise de la social-démocratie','https://www.marxists.org/francais/luxembur/junius/index.html',None),
('4c84babcd61ca7349b09','',"L'impérialisme, stade suprême du capitalisme",'https://www.marxists.org/francais/lenin/works/1916/vlimperi/vlimp.htm','Imperialism, the Highest Stage of Capitalism'),
('2b271fab31937df85f2c','','La révolution trahie','https://www.marxists.org/francais/trotsky/livres/revtrahie/frodcp.htm','The Revolution Betrayed'),
('a66fa62729e3105fc2bd','Bolchevisme ou stalinisme','Bolchevisme contre stalinisme','https://www.marxists.org/francais/trotsky/livres/bcs/bcs05.htm',None),
('cd033d7826694671f9b4','','Programme de transition','https://www.marxists.org/francais/trotsky/livres/trans/tran.htm','The Transitional Program'),
]

def run(db):
    cases=[];start=perf_counter()
    for cid,article,work,url,old in CASES:
        result=lookup(db,[url],article,work)
        en=[e for c in result['candidates'] for e in c['en_candidates']]
        clean=len(result['candidates'])==1 and len(en)==1 and not result['conflicting_url_and_title'] and not en[0]['ambiguous_mapping'] and not en[0]['ambiguous_metadata']
        cases.append({'id':'inventory-'+cid,'article':article,'work':work,'source_url':url,'previous_english_work':old,'result':result,'single_linked_work_candidate':clean,'prior_root_recovered':bool(old and any(e['title']==old for e in en))})
    summary={'scope':'Bibliographic navigation only; fixed previously examined cases, not a blind test; no independent quotation reference or author/edition verification; no network requests.','baseline_run':'https://github.com/wikinuma/wikidebia-quote-resolver/actions/runs/45670611930','cases':len(cases),'previous_work_candidates':sum(c['previous_english_work'] is not None for c in cases),'local_fr_matches':sum(bool(c['result']['candidates']) for c in cases),'local_url_matches':sum(bool(c['result']['matched_source_urls']) for c in cases),'local_english_candidates':sum(any(r['en_candidates'] for r in c['result']['candidates']) for c in cases),'local_single_linked_work_candidates':sum(c['single_linked_work_candidate'] for c in cases),'previous_roots_recovered':sum(c['prior_root_recovered'] for c in cases),'new_single_linked_work_candidates':sum(c['single_linked_work_candidate'] and not c['previous_english_work'] for c in cases),'elapsed_lookup_seconds':round(perf_counter()-start,6),'network_requests':0,'auto_publish':False}
    return {'summary':summary,'cases':cases}

if __name__=='__main__':
    p=Path(__file__).parent
    with sqlite3.connect((p/'wikirouge-index.sqlite3').resolve().as_uri()+'?mode=ro',uri=True) as db: report=run(db)
    (p/'benchmark.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report['summary'],ensure_ascii=False,indent=2))
    for c in report['cases']:
        print(c['article'] or c['work'],':',c['result']['method'],'=>',[e['title'] for r in c['result']['candidates'] for e in r['en_candidates']], 'clean',c['single_linked_work_candidate'])
