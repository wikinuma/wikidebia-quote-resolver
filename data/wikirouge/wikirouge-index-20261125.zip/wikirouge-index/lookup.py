#!/usr/bin/env python3
"""Read-only bibliographic lookup; never establishes an exact translated quotation."""
import argparse
import json
import sqlite3
from pathlib import Path
from build_index import search_title,url_info

def vals(db,lang,pid,field):
    return [r[0] for r in db.execute('SELECT value FROM fields WHERE lang=? AND id=? AND field=? ORDER BY template_no,ordinal',(lang,pid,field))]

def get_page(db,lang,pid):
    r=db.execute('SELECT title,revision,url,status FROM pages WHERE lang=? AND id=?',(lang,pid)).fetchone()
    if not r:raise ValueError('missing page')
    return {'language':lang,'pageid':pid,'title':r[0],'revision':r[1],'wikirouge_url':r[2],'status':r[3], 'authors':vals(db,lang,pid,'author'),'dates':vals(db,lang,pid,'date'),'mia_urls_raw':vals(db,lang,pid,'mia_url')}

def lookup(db,source_urls=(),article='',work=''):
    # Exact source links first; chapter links can differ from work roots.
    url_ids=set(); url_evidence=[]
    for v in source_urls:
        _,k=url_info(v)
        rows=db.execute('SELECT id FROM source_urls WHERE lang=? AND value=?',('fr',v)).fetchall()
        if not rows and k: rows=db.execute('SELECT id FROM source_urls WHERE lang=? AND mia_key=?',('fr',k)).fetchall()
        ids={r[0] for r in rows};url_ids.update(ids)
        if ids:url_evidence.append(v)
    title_ids={}
    for label,t in [('article',article),('work',work)]:
        if t:title_ids[label]={r[0] for r in db.execute('SELECT id FROM pages WHERE lang=? AND search_key=?',('fr',search_title(t)))}
    chosen=set();method='not_found';conflict=False
    if url_ids:
        chosen=url_ids;method='source_url'
        # An article is more specific than a containing work.
        names=title_ids.get('article') or title_ids.get('work') or set()
        if names:
            both=chosen&names
            if both:chosen=both;method='source_url_and_title'
            else:conflict=True
    elif title_ids.get('article'):
        chosen=title_ids['article'];method='article_title'
    elif title_ids.get('work'):
        chosen=title_ids['work'];method='work_title'
    candidates=[]
    for f in sorted(chosen):
        fr=get_page(db,'fr',f)
        en=[]
        for e,ev,fd,ed,ma in db.execute('SELECT en_id,evidence,fr_degree,en_degree,metadata_ambiguous FROM pairs WHERE fr_id=? ORDER BY en_id',(f,)):
            en.append({**get_page(db,'en',e),'native_link_directions':ev.split(','),'ambiguous_mapping':fd>1 or ed>1,'ambiguous_metadata':bool(ma)})
        candidates.append({'fr':fr,'en_candidates':en})
    return {'method':method,'conflicting_url_and_title':conflict,'matched_source_urls':url_evidence,'multiple_fr_candidates':len(chosen)>1,'candidates':candidates,'auto_publish':False}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('index',type=Path);p.add_argument('--url',action='append',default=[]);p.add_argument('--article',default='');p.add_argument('--work',default='');a=p.parse_args()
    with sqlite3.connect(a.index.resolve().as_uri()+'?mode=ro',uri=True) as db: print(json.dumps(lookup(db,a.url,a.article,a.work),ensure_ascii=False,indent=2))
