#!/usr/bin/env python3
"""Build a local bibliographic index from an existing Wikirouge export.
No network requests. The source checkpoint is opened read-only.
"""
import argparse
import collections
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import tempfile
import unicodedata
from urllib.parse import urlsplit

SCHEMA = 'wikirouge-bibliographic-index-1'

def exact_title(s):
    return ' '.join(unicodedata.normalize('NFC', s.replace('_', ' ')).split())

def search_title(s):
    return exact_title(s).replace('\u2019', "'").replace('\u02bc', "'").casefold()

def url_info(value):
    try:
        p = urlsplit(value)
        if p.scheme not in ('http','https') or not p.hostname or p.username or p.password or any(c.isspace() or ord(c)<32 for c in value):
            return None, None
        # Only scheme and www differences for marxists.org are normalized.
        # Other archives and mirrors retain their own hostnames.
        port = p.port
        host = p.hostname.lower()
        if host in ('www.marxists.org','marxists.org') and port in (None,80,443):
            return host, 'marxists.org'+(p.path or '/')+('?' + p.query if p.query else '')
        return host, None
    except ValueError:
        return None,None

SQL = '''
PRAGMA foreign_keys=ON;
CREATE TABLE info(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE pages(lang TEXT NOT NULL,id INTEGER NOT NULL,title TEXT NOT NULL,title_key TEXT NOT NULL,search_key TEXT NOT NULL,revision INTEGER,revision_timestamp TEXT,url TEXT,work_root TEXT,status TEXT,template_names TEXT NOT NULL,issues TEXT NOT NULL,PRIMARY KEY(lang,id));
CREATE TABLE fields(lang TEXT NOT NULL,id INTEGER NOT NULL,template_no INTEGER NOT NULL,template TEXT NOT NULL,field TEXT NOT NULL,ordinal INTEGER NOT NULL,parameter TEXT,value TEXT NOT NULL,PRIMARY KEY(lang,id,template_no,field,ordinal),FOREIGN KEY(lang,id) REFERENCES pages(lang,id));
CREATE TABLE source_urls(lang TEXT NOT NULL,id INTEGER NOT NULL,value TEXT NOT NULL,host TEXT,mia_key TEXT,PRIMARY KEY(lang,id,value),FOREIGN KEY(lang,id) REFERENCES pages(lang,id));
CREATE TABLE native_links(lang TEXT NOT NULL,id INTEGER NOT NULL,target_lang TEXT NOT NULL,target_title TEXT NOT NULL,target_id INTEGER,PRIMARY KEY(lang,id,target_lang,target_title),FOREIGN KEY(lang,id) REFERENCES pages(lang,id));
CREATE TABLE pairs(fr_id INTEGER NOT NULL,en_id INTEGER NOT NULL,evidence TEXT NOT NULL,fr_degree INTEGER NOT NULL,en_degree INTEGER NOT NULL,metadata_ambiguous INTEGER NOT NULL,PRIMARY KEY(fr_id,en_id));
CREATE INDEX page_title ON pages(lang,title_key);
CREATE INDEX page_search ON pages(lang,search_key);
CREATE INDEX page_root ON pages(lang,work_root);
CREATE INDEX url_value ON source_urls(lang,value);
CREATE INDEX url_mia ON source_urls(lang,mia_key);
CREATE INDEX pair_en ON pairs(en_id);
'''

def build(checkpoint, output):
    if output.exists(): raise FileExistsError(output)
    with tempfile.TemporaryDirectory() as temp:
        if checkpoint.suffix=='.gz':
            srcpath=Path(temp)/'checkpoint.sqlite3'
            with gzip.open(checkpoint,'rb') as src, srcpath.open('wb') as dst: shutil.copyfileobj(src,dst)
        else: srcpath=checkpoint
        digest=hashlib.file_digest(srcpath.open('rb'),'sha256').hexdigest()
        with sqlite3.connect(srcpath.resolve().as_uri()+'?mode=ro',uri=True) as src:
            assert src.execute('PRAGMA integrity_check').fetchone()==('ok',), 'source integrity'
            settings=dict(src.execute('SELECT key,value FROM settings'))
            if settings.get('schema')!='wikirouge-metadata-1': raise ValueError('unsupported source schema')
            cats=src.execute('SELECT lang,name,done FROM categories ORDER BY lang,name').fetchall()
            if not cats or any(not d for _,_,d in cats): raise ValueError('incomplete category inventory')
            n,ready=src.execute('SELECT count(*),count(metadata) FROM pages').fetchone()
            if n!=ready: raise ValueError('incomplete source metadata')
            records=[]
            for lang,pid,title,blob in src.execute('SELECT lang,id,title,metadata FROM pages ORDER BY lang,id'):
                r=json.loads(blob)
                if (r['language'],r['pageid'],r['title'])!=(lang,pid,title): raise ValueError('metadata identity mismatch')
                records.append(r)
            cats_counts=src.execute('SELECT c.lang,c.name,c.done,count(m.id) FROM categories c LEFT JOIN members m USING(lang,name) GROUP BY c.lang,c.name').fetchall()
        by_title=collections.defaultdict(list)
        for r in records:by_title[r['language'],exact_title(r['title'])].append(r)
        by_id={(r['language'],r['pageid']):r for r in records}
        with sqlite3.connect(output) as dst:
            dst.executescript(SQL)
            links=collections.defaultdict(set)
            for r in records:
                lang,pid,title=r['language'],r['pageid'],r['title']
                ts=r['templates']
                dst.execute('INSERT INTO pages VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(lang,pid,title,exact_title(title),search_title(title),r['revision'],r['revision_timestamp'],r['url'],r['work_root_candidate'],r['status'],json.dumps([t['template'] for t in ts],ensure_ascii=False),json.dumps(r['issues'],ensure_ascii=False)))
                for i,t in enumerate(ts):
                    for field,values in t['fields'].items():
                        for j,v in enumerate(values):
                            dst.execute('INSERT INTO fields VALUES(?,?,?,?,?,?,?,?)',(lang,pid,i,t['template'],field,j,v['parameter'],v['value']))
                            if field=='mia_url' and v['value'].strip():
                                value=v['value'].strip();host,mia=url_info(value)
                                dst.execute('INSERT OR IGNORE INTO source_urls VALUES(?,?,?,?,?)',(lang,pid,value,host,mia))
            for r in records:
                lang,pid=r['language'],r['pageid']
                for ll in r['native_langlinks']:
                    tl=ll['language'];target=by_title.get((tl,exact_title(ll['title'])),[])
                    tid=target[0]['pageid'] if len(target)==1 else None
                    dst.execute('INSERT OR IGNORE INTO native_links VALUES(?,?,?,?,?)',(lang,pid,tl,ll['title'],tid))
                    if tid is not None and (lang,tl) in (('en','fr'),('fr','en')):
                        pair=(tid,pid) if lang=='en' else (pid,tid)
                        links[pair].add(lang)
            fc=collections.Counter(f for f,e in links);ec=collections.Counter(e for f,e in links)
            for (f,e),ev in sorted(links.items()):
                amb=int(any(by_id[l,i]['status']!='metadata' for l,i in [('fr',f),('en',e)]))
                dst.execute('INSERT INTO pairs VALUES(?,?,?,?,?,?)',(f,e,','.join(sorted(ev)),fc[f],ec[e],amb))
            info={'schema':SCHEMA,'source_schema':settings['schema'],'source_sha256':digest,'source_started_at':settings.get('started_at'),'pages':n,'source_categories':cats_counts,'pairs':len(links),'distinct_fr_linked':len(fc),'distinct_en_linked':len(ec),'scope':'Original metadata fields, native interlanguage candidates only; no full texts, no network or translation verification.'}
            dst.executemany('INSERT INTO info VALUES(?,?)',[(k,json.dumps(v,ensure_ascii=False)) for k,v in info.items()]);dst.commit()
            dst.execute('ANALYZE');dst.commit()
            assert dst.execute('PRAGMA integrity_check').fetchone()==('ok',)
            assert dst.execute('PRAGMA foreign_key_check').fetchall()==[]
            assert dst.execute('SELECT count(*) FROM pages').fetchone()[0]==n
            assert dst.execute('SELECT count(*) FROM pairs').fetchone()[0]==len(links)
            print(json.dumps(info,ensure_ascii=False,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('checkpoint',type=Path);p.add_argument('output',type=Path);a=p.parse_args();build(a.checkpoint,a.output)
