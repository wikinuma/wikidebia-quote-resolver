# Index bibliographique Wikirouge — 25 novembre 2026

Construit localement à partir du checkpoint complet fourni (30 583 pages). Aucun téléchargement du texte ni requête réseau supplémentaire.

- `wikirouge-index.sqlite3` : base de recherche, valeurs originales des paramètres, révisions, URLs, liens natifs et correspondances. Les miroirs restent distincts ; une URL candidate n'est pas une preuve de traduction.
- `build_index.py` : reconstruction à partir du checkpoint SQLite d'origine (compressé ou non).
- `lookup.py` : recherche locale par URL française, article ou oeuvre ; conserve les ambiguïtés.
- `benchmark.py` / `benchmark.json` : comparaison de la recherche bibliographique sur les 14 cas déjà étudiés dans l'expérience GitHub (run 45670611930). Les résultats ne sont pas des citations vérifiées ni un test indépendant de rappel.

Exemple (Python 3.11+, sans bibliothèque externe) :

```
python3 lookup.py wikirouge-index.sqlite3 --work "Anti-Dühring"
python3 benchmark.py
```

Reconstruction :

```
python3 build_index.py chemin/vers/checkpoint.sqlite3.gz nouvel-index.sqlite3
```

Le checkpoint initial reste la référence complète, avec les empreintes des wikicodes ; l'index est un dérivé destiné à la recherche, non une sauvegarde intégrale du checkpoint. Les 777 cibles de liens non résolues sont conservées. Les 32 titres français ayant plusieurs correspondances anglaises ne sont pas arbitrés automatiquement. Le résultat d'une recherche doit encore être vérifié quant à l'auteur, à l'édition, au passage, et aux droits de réutilisation. Aucun déploiement ni modification des wikis.
